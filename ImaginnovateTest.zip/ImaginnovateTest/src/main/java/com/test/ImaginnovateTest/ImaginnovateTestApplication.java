package com.test.ImaginnovateTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImaginnovateTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImaginnovateTestApplication.class, args);
	}

}
