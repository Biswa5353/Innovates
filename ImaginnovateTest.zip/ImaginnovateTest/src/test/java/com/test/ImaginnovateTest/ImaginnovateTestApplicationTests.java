package com.test.ImaginnovateTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImaginnovateTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
